import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-blast',
  templateUrl: './text-blast.component.html',
  styleUrls: ['./text-blast.component.scss']
})
export class TextBlastComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
